import type { Metadata, Viewport } from "next";
import { Sora, Inter } from "next/font/google";
import "./globals.css";

const sora = Sora({
  subsets: ["latin"],
  variable: "--font-sora",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://developersmatrix.com"),
  title: "DevelopersMatrix - 20+ Free AI Tools for Everyone",
  description:
    "Discover 20+ free AI-powered tools for resume building, budget planning, interview preparation, and more. Read latest tech trends. No signup needed.",
  keywords: [
    "free AI tools",
    "AI resume builder",
    "free resume maker",
    "cover letter generator",
    "interview preparation",
    "salary estimator",
    "budget planner",
    "expense tracker",
    "career tools",
    "productivity tools",
    "job search tools",
    "tech trends 2026",
    "AI content detector",
    "website audit tool",
    "habit tracker",
    "personal finance",
    "startup ideas",
  ],
  authors: [{ name: "Syed Bilal Shah" }],
  creator: "Syed Bilal Shah",
  publisher: "DevelopersMatrix",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: {
    google: "cT-3Tl1WSPU8XVdWcDf_MGmGZ8GtOiNmBDdBDytV23A",
  },
  openGraph: {
    title: "DevelopersMatrix - 20+ Free AI Tools for Everyone",
    description:
      "Discover 20+ free AI-powered tools for resume building, budget planning, interview preparation, and more. Read latest tech trends.",
    url: "https://developersmatrix.com",
    siteName: "DevelopersMatrix",
    locale: "en_US",
    type: "website",
    images: [
      {
        url: "https://developersmatrix.com/og-image.png",
        width: 1200,
        height: 630,
        alt: "DevelopersMatrix - Free AI Tools Platform",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    creator: "@developersmatrix",
    title: "DevelopersMatrix - 20+ Free AI Tools for Everyone",
    description:
      "Discover free AI-powered tools for resume building, budget planning, interview prep, and more.",
    images: ["https://developersmatrix.com/og-image.png"],
  },
  alternates: {
    canonical: "https://developersmatrix.com",
  },
};

export const viewport: Viewport = {
  themeColor: "#7c3aed",
  width: "device-width",
  initialScale: 1,
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "DevelopersMatrix",
  url: "https://developersmatrix.com",
  description:
    "AI-powered platform with 20+ free tools for career growth, productivity, finance and tech insights.",
  publisher: {
    "@type": "Organization",
    name: "DevelopersMatrix",
    url: "https://developersmatrix.com",
    sameAs: [
      "https://linkedin.com/company/developersmatrix",
      "https://www.facebook.com/developersmatrix/",
      "https://www.instagram.com/developermatrix/",
      "https://www.pinterest.com/developersmatrix/",
    ],
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${sora.variable} ${inter.variable}`}>
      <body>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        {children}
      </body>
    </html>
  );
}
