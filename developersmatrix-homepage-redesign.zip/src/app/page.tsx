import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";
import LiveTicker from "@/components/sections/live-ticker";
import HeroDiscovery from "@/components/sections/hero-discovery";
import FeaturedGrid from "@/components/sections/featured-grid";
import ToolExplorer from "@/components/sections/tool-explorer";
import TrendingNow from "@/components/sections/trending-now";
import ExploreByGoal from "@/components/sections/explore-by-goal";
import ArticlesCarousel from "@/components/sections/articles-carousel";
import ToolStack from "@/components/sections/tool-stack";
import LatestUpdates from "@/components/sections/latest-updates";
import { Newsletter, FinalCta } from "@/components/sections/newsletter-cta";

export default function HomePage() {
  return (
    <>
      <SiteHeader />
      <main>
        <LiveTicker />
        <HeroDiscovery />
        <FeaturedGrid />
        <ToolExplorer />
        <TrendingNow />
        <ExploreByGoal />
        <ArticlesCarousel />
        <ToolStack />
        <LatestUpdates />
        <Newsletter />
        <FinalCta />
      </main>
      <SiteFooter />
    </>
  );
}
