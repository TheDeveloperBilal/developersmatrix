# DevelopersMatrix Homepage Redesign — Handoff Notes

This package contains a complete new homepage, header (mega menu + search bar)
and footer for developersmatrix.com. Next.js 15 App Router + TypeScript + Tailwind.

## What is included
- `src/app/page.tsx` — new homepage
- `src/app/layout.tsx` — fonts (Sora + Inter) + SEO metadata + JSON-LD
- `src/app/globals.css` — design system styles
- `src/components/` — site-header (mega menu + search), site-footer, all homepage sections
- `src/lib/` — content data (tools, trends, goals, articles)
- `public/images/` — 6 editorial images used by cards/articles
- `tailwind.config.ts`, `postcss.config.mjs`, `next.config.ts`, `tsconfig.json`, `package.json`

## Merge instructions (for the coding agent)
- This package contains ONLY the homepage — merge it into the existing site.
  Do NOT replace the whole project; all inner pages and routes must keep working.
- Replace the current homepage with `src/app/page.tsx` + `src/components/`.
- Use the new `site-header.tsx` (mega menu + search bar) and `site-footer.tsx`
  on ALL pages.
- Install new dependencies: `npm install framer-motion lucide-react`
- Copy `public/images/*`, Tailwind config, fonts and `globals.css`.
- Remove `output: "export"` from next.config — keep the existing production build setup.
- Do NOT change existing URLs, slugs, metadata or SEO tags.
- After merging: run the build, fix errors, show a preview before deploying.
